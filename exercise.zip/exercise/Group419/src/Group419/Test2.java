package Group419;

import static org.junit.Assert.*;

import org.junit.Ignore;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import junit.framework.Assert;

public class Test2 {


	@Test
	//Password should not more than 6
	public void test6() throws InterruptedException {
		
			
			System.setProperty("webdriver.chrome.driver", "C:\\\\Users\\\\Roshne Parmar\\\\Documents\\\\drivers/chromedriver.exe");
		    WebDriver driver = new ChromeDriver();
		    driver.get("http://localhost:3000/");

		    
		    WebElement e_id = driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/form/div[1]/div/div[1]/div/div/input"));
			e_id.sendKeys("roshni@gmail.com");
		   
		   Thread.sleep(2000);
		   WebElement password=  driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/form/div[1]/div/div[2]/div/div/input"));
		   password.sendKeys("roshn");
		   
		   WebElement retype_password = driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/form/div[1]/div/div[3]/div/div/input"));
		   retype_password.sendKeys("roshn");
		   
		   driver.quit();

	}
	@Test
	// display reset button
	public void test7() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\\\\\\\Users\\\\\\\\Roshne Parmar\\\\\\\\Documents\\\\\\\\drivers/chromedriver.exe");
	    WebDriver driver = new ChromeDriver();
	    driver.get("http://localhost:3000/");
	    driver.manage().window().maximize();
	   
	    boolean reset= driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/form/div[5]/button[1]")).isDisplayed();
	    driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/form/div[5]/button[1]")).submit();
	    Assert.assertTrue(reset);
	    Thread.sleep(500);
	    driver.quit();
	}
	@Test
	// display apply button
	public void test8() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\\\\\\\Users\\\\\\\\Roshne Parmar\\\\\\\\Documents\\\\\\\\drivers/chromedriver.exe");
	    WebDriver driver = new ChromeDriver();
	    driver.get("http://localhost:3000/");
	    driver.manage().window().maximize();
	   
	    boolean apply= driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/form/div[5]/button[2]")).isDisplayed();
	    Assert.assertTrue(apply);
	    Thread.sleep(500);
	    driver.quit();
	}


}
